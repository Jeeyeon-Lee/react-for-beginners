import React from 'react'

const HomePage = () => {
  return (
    <>
     <bookHeader />
     <div>본문</div>
     <bookFooter />
  )
}

export default HomePage