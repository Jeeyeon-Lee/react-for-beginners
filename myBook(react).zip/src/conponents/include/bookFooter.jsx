import React from 'react'

const bookFooter = () => {
  return (
    <div>bookFooter</div>
  )
}

export default bookFooter